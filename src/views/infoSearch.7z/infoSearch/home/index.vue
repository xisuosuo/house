<template>
  <div id="viewDiv" region="center">
  <div class="tools">
  <MapToolsView :mapView="mapview" v-if="IsMapToolsView" :url="toolsUrl" ></MapToolsView></div>
  <div class="search">  
    <Dropdown trigger="custom" :visible="visible"  style="width: 330px" >
      <i-input v-model="txt_input" icon="ios-search"  width="330px"
        @on-click="onSearchClick"
        @on-enter="onSearchClick">
        <i-select v-model="txt_select" slot="prepend" style="width: 80px">
          <Option value="小区" label="小区">
            <span>小区</span>
          </Option>
          <Option value="单位区" label="单位区">
            <span>单位区</span>
          </Option>
        </i-select>
      </i-input>
      <!-- <div class="close-wrapper" @click="onClosePanel">
        <Tooltip content="清除" placement="bottom">
          <span>
            <i class="icon-empty-close" v-if="!loading"></i>
            <Icon type="load-a" class="ivu-load-loop" size="20" v-else-if="loading"></Icon>
          </span>
        </Tooltip>
      </div> -->
       <DropdownMenu slot="list">
        <div v-if="data.length===0" class="message"><a>未找到相关信息</a></div>
        <div class="list-wrapper" :style="{maxHeight:height+'px'}" v-else>
          <item v-for="(item,id) in list" :key="item.id" :data="item" :id="id+1" @on-item-click="onItemClick"/>
        </div>
        <div class="page-footer" v-show="data.length>10">
         <Page :total="data.length" :page-size="pageSize" size="small" @on-change="onPageChange"></Page>
        </div>
      </DropdownMenu>
    </Dropdown>
  </div>
    <div class="mapbar">
    <ul>
      <li class="btn">
        <span class="icon baseLayer" @click="switch3d" ></span>
        <span>3D</span>
      </li>
      <li id="switchbasemap"  @click="switchbasemap">
        <span class="icon baseLayerImg" ></span>
        <span>影像</span>
      </li>
      <li class="btn"  @click="onToggleLayer">
        <span class="icon layerView" ></span>
        <span>图层</span>
      </li>
    </ul>
  </div>
  </div>
</template>
<script>
import esriLoader from "esri-loader";
import { MapAPI } from "@/core/config/const";
// import infoSearch from "../infoSearch/index.vue";
import Item from "./components/item";
import Register from "@/map/api/register";
import Server from "@/core/server";
import { services } from "@/core/config/services";
import measureArea from "@/map/components/measureArea";
import measureLength from "@/map/components/measureLength";
import MapToolsView from "@/map/components/MapToolsView";
import GDrawSketch from "@/map/api/4+/GDrawSketch";
import GConvertGeometry from "@/map/api/js/convert/GConvertGeometry";
export default {
  data() {
    return {
      visible: false,
      isShow: false,
      shape: "",
      txt_input: "",
      list: [],
      dialog: false,
      pageSize: 10,
      txt_select: "",
      data: [],
      baseLayer: "",
      street: "",
      isExtent: true,
      isPopup: false,
      isPan: true,
      cityList: [
        {
          value: "小区",
          label: "小区"
        },
        {
          value: "单位区",
          label: "单位区"
        }
      ],
      defaultMapExtent: "13191914.41591351,3804132.145961022,3",
      spatialReference: "",
      toolsUrl: "js/json/common_tools.json",
      mapTileLayerLayers: "",
      TileLayerStreets: "",
      MapImageLayer: "",
      mapview: null,
      IsMapToolsView: false
    };
  },
  computed: {
    height() {
      return document.body.clientHeight - 450;
    }
  },
  watch: {
    data() {
      this.onPageChange(1);
    }
  },
  mounted() {
    this.spatialReference = "";
    this.addLayer(mapView => {
      this.mapLoaded(mapView);
    });
    this.register();
    // setTimeout(() => {
    //   this.showGraphics();
    // }, 600);
  },
  methods: {
    switch3d() {
      this.$router.push("/3dmap");
    },
    register() {
      //接收外部结果
      onemap.pubsub.subscribe("showQuickSearchResult", arg => {
        this.isExtent = false;
        this.isPan = false;
        this.isPopup = arg.isPopup || true;
        this.data = arg.list;
        this.visible = true;
      });
      onemap.pubsub.subscribe("hideQuickSearchResult", arg => {
        this.visible = false;
        this.data = [];
      });

      //clear
      onemap.pubsub.subscribe("clear", arg => {
        this.visible = false;
        this.data = [];
      });
    },
    mapLoaded(mapView) {
      new Register(mapView)
        .mapEvent()
        .mapAPI()
        .parentMapAPI();
      if (this.isIQuery) {
        new GIQuery({
          mapView: mapView,
          isPopup: this.isIPopup
        }).toggle();
      }
    },
    onToggleLayer() {
      if (document.getElementsByClassName) {
        var target = document.getElementsByClassName("esri-layer-list");
        var targetName = target[0];
        if (targetName.style.display == "block") {
          targetName.style.display = "none";
        } else {
          targetName.style.display = "block";
        }
      }
    },
    addLayer(callback) {
      esriLoader
        .loadScript({
          url: MapAPI.js,
          css: MapAPI.css
        })
        .then(r => {
          esriLoader
            .loadModules([
              "esri/config",
              "esri/Map",
              "esri/layers/GroupLayer",
              "esri/Basemap",
              "esri/views/MapView",
              "esri/layers/MapImageLayer",
              "esri/layers/TileLayer",
              "esri/geometry/Extent",
              "esri/widgets/LayerList"
            ])
            .then(
              ([
                esriConfig,
                Map,
                GroupLayer,
                Basemap,
                MapView,
                MapImageLayer,
                TileLayer,
                Extent,
                LayerList,
                dom,
                on
              ]) => {
                esriConfig.request.corsEnabledServers.push("192.168.1.104/");
                var activeWidget = null;

                var layer = new TileLayer({
                  url:
                    "https://192.168.1.108:6443/arcgis/rest/services/ChuZhou/chuZhou/MapServer"
                });
                this.baseLayer = layer;

                var street = new TileLayer({
                  url:
                    "	https://localhost:6443/arcgis/rest/services/ChuZhou/ChuZhouYX/MapServer",
                  visible: false
                });

                this.street = street;
                var USALayer = new MapImageLayer({
                  url:
                    "https://192.168.1.108:6443/arcgis/rest/services/ChuZhou/行政区划/MapServer",
                  visible: false
                });

                var censusLayer = new MapImageLayer({
                  url:
                    "https://192.168.1.108:6443/arcgis/rest/services/ChuZhou/yewuData/MapServer",
                  title: "业务数据",
                  visible: false
                });
                var baseMap = new Basemap({
                  baseLayers: [layer, street]
                });
                var demographicGroupLayer = new GroupLayer({
                  title: "专题图层",
                  visible: true,
                  visibilityMode: "independent",
                  layers: [USALayer, censusLayer]
                  // opacity: 0.75
                });

                var map = new Map({
                  basemap: baseMap,
                  layers: [demographicGroupLayer]
                });
                var ext = String(this.defaultMapExtent).split(",");
                if (ext.length > 3) {
                  console.log("extent 配置有误");
                  return false;
                }
                var zoom = parseInt(ext[2]);
                var center = {
                  x: parseFloat(ext[0]),
                  y: parseFloat(ext[1]),
                  spatialReference: this.spatialReference
                };
                this.mapview = new MapView({
                  container: "viewDiv",
                  map: map,
                  zoom: zoom,
                  center: center
                });

                this.mapview.ui.remove(["attribution", "zoom"]);
                var view = this.mapview;
                view.when(function() {
                  var layerList = new LayerList({
                    view: view
                  });
                  view.ui.add(layerList, "top-right");
                });

                this.mapview.initExtent = {
                  center: center,
                  zoom: zoom
                };
                window.mapview = this.mapview;
                callback(this.mapview);
                this.IsMapToolsView = true;
              }
            );
        });
    },
    switchbasemap() {
      if (this.baseLayer.visible) {
        this.baseLayer.visible = false;
        this.street.visible = true;
      } else {
        this.baseLayer.visible = true;
        this.street.visible = false;
      }
    },
    onSearchClick() {
      debugger;
      if (this.txt_select == "小区") {
        Server.get({
          url: services.houseQuery,
          params: {
            name: this.txt_input
          }
        }).then(
          rsp => {
            var _this = this;
            if (rsp.status === 1) {
              _this.data = rsp.data;
              _this.list = rsp.data;
            } else {
              _this.data = [];
            }
            _this.visible = true;
          },
          error => {
            this.$Message.warning(error.message);
          }
        );
      }
     else{
        Server.get({
          url: services.companyQuery,
          params: {
            name: this.txt_input
          }
        }).then(
          rsp => {
            var _this = this;
            if (rsp.status === 1) {
              _this.data = rsp.data;
              _this.list = rsp.data;
            } else {
              _this.data = [];
            }
            _this.visible = true;
          },
          error => {
            this.$Message.warning(error.message);
          }
        );
      }
    },
    onPageChange(page) {
      let data = [];
      for (
        var i = (page - 1) * this.pageSize, len = this.data.length, item;
        i < len, (item = this.data[i]);
        i++
      ) {
        if (i < page * this.pageSize) {
          item.pIndex = "p" + i;
          data.push(item);
        } else {
          break;
        }
      }
      this.list = data;
      this.showGraphics();
    },
    onItemClick(data) {
      this.$emit("on-item-click", data);
      onemap.pubsub.publish("showQuickClick", data);
      //循环定位
      for (var i = 0, g; (g = this.mapview.graphics.items[i]); i++) {
        if (g.attributes.id === data.pIndex) {
          var geometry = null;
          if (g.geometry.type === "point") {
            geometry = g.geometry;
          } else {
            var extent = g.geometry.extent.clone();
            geometry = extent.expand(2);
          }
          this.mapview.goTo(geometry);
          var attributes = g.attributes;
          mapApi.popup.show({
            mapView: this.mapview,
            res: attributes.attr,
            centerPt: attributes.centerPt
          });
          break;
        }
      }
    },
    showGraphics() {
      this.mapview.graphics.removeAll();
      if (this.list === 0) return;
      onemap.pubsub.publish("drawPolygonByList", {
        list: this.list,
        extent: this.isExtent
      });
      onemap.pubsub.publish("drawMarkerByList", {
        list: this.list,
        popup: this.isPopup,
        pan: this.isPan
      });
    },
    watchLayer() {}
  },
  components: {
    measureArea,
    measureLength,
    MapToolsView,
    Item
  }
};
</script>
<style >
#viewDiv {
  padding: 0;
  margin: 0;
  height: 1000px;
  width: 100%;
}
.main .container-fluid {
  padding: 0 0px;
}
.breadcrumb {
  position: relative;
  margin-bottom: 0.01rem;
  border-bottom: 1px solid #cfd8dc;
}
#layerToggle {
  top: 20px;
  right: 20px;
  position: absolute;
  z-index: 99;
  background-color: white;
  border-radius: 8px;
  padding: 10px;
  opacity: 0.75;
}
.baidu {
  position: absolute;
  right: 0;
  top: 115px;
}

.tools {
  position: absolute;
  top: 60px;
  left: 80px;
}
.search {
  position: absolute;
  top: 58px;
  left: 120px;
}
.list-wrapper {
  padding: 10px;
  overflow-y: auto;
}
.esri-layer-list__item-title {
  margin-left: -5px;
  padding-left: -5px;
}
#switchbasemap {
  float: left;
  padding: 0 10px 0 4px;
  height: 30px;
  line-height: 30px;
  background: #ffffff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
  transition: all 0.2s;
  cursor: pointer;
}
</style>