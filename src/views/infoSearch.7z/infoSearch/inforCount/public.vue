<template>
    <Layout >
        <Modal v-model="PublicFacility1"  draggable title="公共设施统计" width="380">
            <Form :label-width="90">
              <FormItem label="街道区域：" prop="zoning">
                <Select  v-model="Street" placeholder="选择街道区域">
                  <Option v-for="item in streetList" :key="item.value" :value="item.value">{{item.label}}</Option>
                </Select> 
              </FormItem>
              <FormItem label="自定义查询：" prop="zoning">
                <Button shape="circle" title="自定义范围" @click="createPolygon">
                  <span class="icon-polygon" ></span>
                </Button>
              </FormItem>   
            </Form>  
            </Modal>
            </Layout >   
            