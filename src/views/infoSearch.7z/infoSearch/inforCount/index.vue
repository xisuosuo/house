<template>
    <Layout >
        <Modal v-model="PublicFacility1"  draggable title="公共设施统计" width="380">
            <Form :label-width="90">
              <FormItem label="街道区域：" prop="zoning">
                <Select  v-model="Street" placeholder="选择街道区域">
                  <Option v-for="item in streetList" :key="item.value" :value="item.value">{{item.label}}</Option>
                </Select> 
              </FormItem>
              <FormItem label="自定义查询：" prop="zoning">
                <Button shape="circle" title="自定义范围" @click="createPolygon">
                  <span class="icon-polygon" ></span>
                </Button>
              </FormItem>   
            </Form>
          <div slot="footer">
             <Button type="primary" size="large" long  @click="getStreet">查询</Button>
          </div>
         </Modal>
         <Modal v-model=" PublicFacility2" draggable scrollable title="公共设施统计" width="800">
             <div slot="footer"><Button type="primary" size="large" long  @click="getStreet">查询</Button></div>
             <Table  size="small" stripe :columns="columns1" :data="data1"></Table>
             <div id="charts" style="width:800px;height:250px;"></div>
          </Modal>
          <Modal v-model="PublicFacility3"  draggable title="缓冲区查询" width="380" >
            <Form :label-width="90">
              <FormItem label="半径 " prop="zoning">
                <Input v-model="distance" placeholder=""></Input>
              </FormItem>
              <FormItem label="选点：" prop="zoning">
                <Button shape="circle" title="自定义选点" @click="createPoint">
                  <span><Icon type="ios-pin-outline"  size="17"/></span>
                </Button>
              </FormItem>   
             </Form>
            <div slot="footer">
              <Button type="primary" size="large" long  @click="getHouse">查询</Button>
            </div>
          </Modal>
</Layout>
</template>
<script>
import Server from "@/core/server";
import { services } from "@/core/config/services";
import GDrawSketch from "@/map/api/4+/GDrawSketch";
import GDrawbuffer from "@/map/api/4+/GDrawBuffer";
import GConvertGeometry from "@/map/api/js/convert/GConvertGeometry";
var echarts = require("echarts");
export default {
  data() {
    return {
      PublicFacility1: false,
      PublicFacility2: false,
      PublicFacility3: false,
      house: "",
      isExtent: true,
      isPopup: true,
      isPan: true,
      distance: "",
      streetList: [
        {
          value: "杨子街道",
          label: "杨子街道"
        },
        {
          value: "大王街道",
          label: "大王街道"
        },
        {
          value: "章广镇",
          label: "章广镇"
        },
        {
          value: "黄泥冈",
          label: "黄泥冈"
        },
        {
          value: "珠龙镇",
          label: "珠龙镇"
        },
        {
          value: "大柳镇",
          label: "大柳镇"
        },
        {
          value: "沙河镇",
          label: "沙河镇"
        },
        {
          value: "腰铺镇",
          label: "腰铺镇"
        },
        {
          value: "施集镇",
          label: "施集镇"
        },
        {
          value: "凤凰街",
          label: "凤凰街"
        },
        {
          value: "清流街",
          label: "清流街"
        },
        {
          value: "琅琊街",
          label: "琅琊街"
        },
        {
          value: "北门街",
          label: "北门街"
        },
        {
          value: "南门街",
          label: "南门街"
        },
        {
          value: "西门街",
          label: "西门街"
        },
        {
          value: "东门街",
          label: "东门街"
        },
        {
          value: "西涧街",
          label: "西涧街"
        },
        {
          value: "乌衣镇",
          label: "乌衣镇"
        },
        {
          value: "龙蟠街道",
          label: "龙蟠街道"
        }
      ],
      columns1: [
        {
          title: "设施名称",
          key: "name",
          align: "center"
        },
        {
          title: "设施数量",
          key: "number",
          align: "center"
        }
      ],
      data1: [
        {
          key: "medical",
          name: "医疗保健",
          number: ""
        },
        {
          key: "school",
          name: "学校",
          number: ""
        },
        {
          key: "station",
          name: "车站",
          number: ""
        },
        {
          key: "telecomHouse",
          name: "电讯营业厅",
          number: ""
        },
        {
          key: "ticket",
          name: "售票点",
          number: ""
        },
        {
          key: "publicFacilities",
          name: "公共设施",
          number: ""
        },
        {
          key: "govermentAgencies",
          name: "政府机构及社会团体",
          number: ""
        }
      ],
      Street: "",
      myChart: null
    };
  },
  mounted() {},
  methods: {
    selectHouse() {
      this.PublicFacility1 = true;
    },
    selectBuffer() {
      this.PublicFacility3 = true;
    },
    getStreet() {
      if (!this.myChart) {
        this.myChart = echarts.init(document.getElementById("charts"));
      }
      this.PublicFacility2 = true;
      var _this = this;
      Server.get({
        url: services.streetquery,
        params: {
          name: _this.Street
        }
      }).then(function(res) {
        let xData = [];
        let yDate = [];
        _this.data1.forEach(element => {
          element.number = res.data[0][element.key]; //对应返回data数据对应的key值
          console.log(res);
          xData.push(element.name);
          yDate.push(res.data[0][element.key]);
        });
        _this.myChart.setOption({
          color: ["#3398DB"],
          tooltip: {
            trigger: "axis",
            axisPointer: {
              type: "shadow"
            }
          },
          grid: {
            left: "3%",
            right: "4%",
            bottom: "3%",
            containLabel: true
          },
          xAxis: [
            {
              type: "category",
              data: xData,
              axisTick: {
                alignWithLabel: true
              },
              axisLabel: {
                interval: 0
              },
              axisLine: {
                show: true,
                lineStyle: {
                  type: "dotted",
                  color: "#696969"
                }
              }
            }
          ],
          yAxis: [
            {
              type: "value"
            }
          ],
          series: [
            {
              name: "数量",
              type: "bar",
              barWidth: "40%",
              data: yDate,
              label: {
                normal: {
                  show: true,
                  position: "top"
                }
              }
            }
          ]
        });
      });
    },
    createPolygon() {
      new GDrawSketch(window.mapview).then(gDraw => {
        this.gDraw = gDraw;
        this.gDraw.create("polygon");
        this.gDraw.on("create-complete", e => {
          let shape = mapApi.convert.toWKTByGeometry.ToWKT(e.geometry);
          console.log(shape);
          this.shape = shape;
          parent.onemap.pubsub.publish("drawPolygon", shape);
        });
      });
    },
    getHouse() {
      Server.post({
        url: services.getHouse,
        params: {
          housePolygon: this.house
        }
      }).then(rsp => {
        if (rsp.status === 1) {
          console.log(rsp.data);
          this.list = rsp.data;
          this.showGraphics();
          this.$Message.success("查询成功");
          // sessionStorage.setItem("userInfo", JSON.stringify(this.user))
        } else {
          this.$Message.error(rsp.message);
        }
      });
    },
    showGraphics() {
      //render graphic
  
      if (this.list === 0) return;
      onemap.pubsub.publish("drawHouseByList", {
        list: this.list,
        popup: this.isPopup,
        pan: this.isPan
      });
    },
    createPoint() {
      new GDrawbuffer(window.mapview).then(gDraw => {
        this.gDraw = gDraw;
        this.gDraw.enableCreatePoint(this.distance, buffer => {
          this.house = mapApi.convert.toWKTByGeometry.ToWKT(buffer);
          // console.log(this.house);
        });
        // console.log(shape1);
        // var buffer = this.gDraw.enableCreatePoint(this.distance);
        // console.log(buffer);
        // console.log(this.gDraw);
        // this.gDraw.on("draw-complete", e => {
        //   // let shape = mapApi.convert.toWKTByGeometry.ToWKT(e.geometry);
        //   // this.shape = shape;
        //   // console.log(this.shape);
        //   // parent.onemap.pubsub.publish("drawPolygon", shape);
        // });
      });
    }
  }
};
</script>
<style lang="less" scoped>
.ivu-form-item {
  margin-bottom: 12px;
  vertical-align: top;
  zoom: 1;
}
.menu-item-title {
  height: 48px;
  line-height: 48px;
  font-size: 14px;
  padding-left: 28px;
}
</style>

