<template>
<div class="login-theme">
        <div class="title">滁州市“房源”推荐系统</div>
     <div class="login-user">
        <i-form ref="user" :model="user" :rules="rules">
            <form-item prop="userAccount">
                <i-input prefix="ios-person-outline"  size="large" v-model="user.userAccount" placeholder="请输入账号"/>
            </form-item>
            <form-item prop="userPwd">
                <i-input prefix="ios-lock-outline" type="password" size="large"  v-model="user.userPwd" @on-enter="checkLogin"  placeholder="请输入密码"/>
            </form-item>
            <form-item class="checkbox">
                <checkbox v-model="user.remember">记住密码</checkbox>
            </form-item>
        </i-form>
        <div class="login-btn">
            <i-button  :loading="loading" long size="large"  @click="checkLogin">登 录</i-button>
        </div>
          <register  ref="register"  class="register" />
    </div>
</div>
</template>

<script>
import { login } from "./js/login";
import Server from "@/core/server";
import register from "@/views/login/register";
export default {
  mixins: [login],
  data() {
    return {};
  },

  components: {
    register
  }
};
</script>

<style lang="less">
/* html {
 background: url("../../assets/img/logo/login_bg.png") center no-repeat;
} */
// #app {
//   min-height: 1920px;
//   background: url("../../assets/img/logo/login_bg.png") center no-repeat;
// }
.title-wrapper {
  position: absolute;
  left: 1%;
}
.title {
  padding-top: 90px;
  font-size: 48px;
  color: #458fe8;
}
.login-theme {
  height: 1980px;
  width: 100%;
  text-align: center;
  background: url("../../assets/img/logo/login_bg.png");
}
.login-user {
  margin-top: 90px;
  .ivu-input {
    border-radius: 24px;
    padding-left: 40px;
    border: 0;
    box-shadow: 0 5px 5px rgba(135, 135, 135, 0.5);
  }
  .ivu-input-prefix {
    left: 10px;
    i {
      font-size: 20px;
    }
  }
  .checkbox {
    float: left;
    .ivu-form-item-content {
      line-height: 1em;
    }
  }
  .login-btn {
    .ivu-btn {
      border-radius: 24px;
      color: white;
      background: linear-gradient(to right, #4979ea, #6cc9f4, #6193fd);
      border: 0;
      box-shadow: 0 5px 5px rgba(135, 135, 135, 0.5);
    }
  }
}
.login-user {
  padding-top: 20px;
  width: 345px;
  margin: 0 auto;
  box-sizing: border-box;
}
.title {
  text-align: center;
  padding-bottom: 20px;
}
.title h2 {
  margin-bottom: 10px;
  font-weight: 300;
  font-size: 30px;
  color: #000;
}
.checkbox {
  margin-top: 15px;
}
.login-btn {
  margin-top: -5px;
}
</style>
